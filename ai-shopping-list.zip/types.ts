
export interface ShoppingListItem {
  id: number;
  name: string;
  completed: boolean;
}
