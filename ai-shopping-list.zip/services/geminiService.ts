
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const getShoppingSuggestions = async (prompt: string): Promise<string[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Generate a simple shopping list as a JSON array of strings for: "${prompt}". For example, for "taco night", you should return something like ["Taco shells", "Ground beef", "Lettuce", "Tomatoes", "Shredded cheese", "Salsa", "Sour cream"]. Only return the raw JSON array, without any markdown formatting.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING,
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const suggestions = JSON.parse(jsonText);

    if (Array.isArray(suggestions) && suggestions.every(item => typeof item === 'string')) {
      return suggestions;
    } else {
      console.error("Gemini API returned an unexpected format:", suggestions);
      return [];
    }
  } catch (error) {
    console.error("Error fetching shopping suggestions:", error);
    return [];
  }
};
